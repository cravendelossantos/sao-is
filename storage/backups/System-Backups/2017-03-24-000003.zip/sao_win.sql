
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `organization` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `school_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,'sample','2016-2017','sample_act','2017-04-08',0,'2017-03-22 20:49:11','2017-03-22 20:49:11');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `colleges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colleges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `colleges` WRITE;
/*!40000 ALTER TABLE `colleges` DISABLE KEYS */;
INSERT INTO `colleges` VALUES (1,'College of Allied Medical Sciences'),(2,'College of Arts and Sciences'),(3,'College of Business Administration'),(4,'College of Engineering, Computer Studies and Architecture'),(5,'College of International Tourism and Hospitality Management');
/*!40000 ALTER TABLE `colleges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `community_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `community_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `violation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `required_hours` int(11) NOT NULL,
  `status` enum('On going','Completed') COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `community_services` WRITE;
/*!40000 ALTER TABLE `community_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `complainants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complainants` (
  `id_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` enum('Guard','Faculty','Student') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `complainants` WRITE;
/*!40000 ALTER TABLE `complainants` DISABLE KEYS */;
INSERT INTO `complainants` VALUES ('2014-0001f','John Doe','Guard'),('2014-0002f','Jane Doe','Guard');
/*!40000 ALTER TABLE `complainants` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `page` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contents` WRITE;
/*!40000 ALTER TABLE `contents` DISABLE KEYS */;
INSERT INTO `contents` VALUES (1,NULL,NULL,'<h1 class=\"lpu-text\" style=\"box-sizing: border-box; margin: 5px 0px 10px; font-size: 48px; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 1.1; color: #2f4050; text-align: center;\"><strong><span style=\"box-sizing: border-box; font-family: \'book antiqua\', palatino, serif; font-size: 40pt;\">STUDENT AFFAIRS OFFICE</span></strong></h1>\n<p><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;</span></p>\n<p style=\"text-align: justify;\"><span style=\"box-sizing: border-box; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"font-size: 15px; text-align: justify;\">&nbsp; &nbsp; The Student Affairs Office (SAO) supports programs that encourage the concept of total student development. It is commited to provide an enviroment conducive to personal, social, emotional, spiritual, and organizational development through involvement in student governance and activities. It continues to plan, implement, evaluate, and support programs and services to meet students needs.</span></span></p>\n<p style=\"text-align: justify;\"><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;</span></p>\n<p style=\"text-align: justify; padding-left: 60px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"> The SAO offers services to the students in the following areas:</span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;1.&nbsp;<span style=\"box-sizing: border-box; font-weight: bold;\">Student Welfare</span></span></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.1. Orientation and Awareness</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.2. Student Handbook Development</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.&nbsp;<span style=\"box-sizing: border-box; font-weight: bold;\">Student Development</span></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.1. Student Organizations and Activities</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.2. Leadership Training</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.3. Student Government</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.4.&nbsp;<em>Student Discipline</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.&nbsp;<span style=\"box-sizing: border-box; font-weight: bold;\">Other Student Service</span></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.1. Lockers</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3.2 Lost and Found</em></span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;</span></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;</span></p>\n<div class=\"row\" style=\"box-sizing: border-box; margin-right: -15px; margin-left: -15px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\">\n<div class=\"col-md-12\" style=\"box-sizing: border-box; position: relative; min-height: 1px; padding-right: 15px; padding-left: 15px; float: left; width: 942px;\">\n<h2 class=\"lpu-text\" style=\"box-sizing: border-box; font-family: inherit; font-weight: 100; line-height: 1.1; color: #8c0001; margin-top: 5px; margin-bottom: 10px; font-size: 24px;\"><span style=\"box-sizing: border-box; font-weight: bold; font-family: \'book antiqua\', palatino, serif;\">Educational Philosophy</span></h2>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\"><em style=\"box-sizing: border-box;\">Lyceum of the Philippines University - Cavite</em>, an institution of higher learning, inspired by the ideals of Philippine President Jose P. Laurel, is committed to the advancement of his philosophy and values:</span></p>\n<blockquote style=\"box-sizing: border-box; padding: 10px 20px; margin: 0px 0px 20px; font-size: 17.5px; border-left: 5px solid #eeeeee;\"><span style=\"color: #000000;\"><span style=\"font-family: \'book antiqua\', palatino, serif;\"><em style=\"box-sizing: border-box;\">\"Veritas et Fortitudo\" (truth and fortitude) \"Pro Deo et Patria\" (for God and Country).</em></span><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;</span></span></blockquote>\n</div>\n</div>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; line-height: 26px;\"><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;</span></p>\n<p><span style=\"font-family: \'book antiqua\', palatino, serif;\">&nbsp;</span></p>\n<div class=\"row\" style=\"box-sizing: border-box; margin-right: -15px; margin-left: -15px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\">\n<div class=\"col-md-12\" style=\"box-sizing: border-box; position: relative; min-height: 1px; padding-right: 15px; padding-left: 15px; float: left; width: 942px;\">\n<h2 class=\"lpu-text\" style=\"box-sizing: border-box; font-family: inherit; font-weight: 100; line-height: 1.1; color: #8c0001; margin-top: 5px; margin-bottom: 10px; font-size: 24px;\"><span style=\"box-sizing: border-box; font-weight: bold; font-family: \'book antiqua\', palatino, serif;\">Core Values</span></h2>\n<table style=\"box-sizing: border-box; border-spacing: 0px; border-collapse: collapse; background-color: transparent; width: inherit; height: 146px;\" border=\"0\" align=\"center\">\n<tbody style=\"box-sizing: border-box;\">\n<tr style=\"box-sizing: border-box;\">\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">L -</span>&nbsp;Love of God</span></td>\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;</span></td>\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">J -</span>&nbsp;Justice</span></td>\n</tr>\n<tr style=\"box-sizing: border-box;\">\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">P -</span>&nbsp;Professional Integrity</span></td>\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">N -</span>&nbsp;Nationalism</span></td>\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">P -</span>&nbsp;Perseverance</span></td>\n</tr>\n<tr style=\"box-sizing: border-box;\">\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">U -</span>&nbsp;Unity</span></td>\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;</span></td>\n<td style=\"box-sizing: border-box; padding: 0px;\"><span style=\"box-sizing: border-box; font-size: x-large; font-family: \'book antiqua\', palatino, serif; color: #000000;\"><span style=\"box-sizing: border-box; font-weight: bold;\">L -</span>&nbsp;Leadership</span></td>\n</tr>\n</tbody>\n</table>\n</div>\n</div>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; font-size: 15px; line-height: 26px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; text-align: left; padding-left: 30px;\"><span style=\"font-family: \'book antiqua\', palatino, serif; color: #000000;\">&nbsp;</span></p>','Home'),(2,NULL,'2017-01-26 19:10:39','<h3 style=\"box-sizing: border-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: 500; line-height: 1.1; color: #8c0001; margin-top: 20px; margin-bottom: 10px; font-size: 14pt;\"><span style=\"font-family: verdana, geneva, sans-serif;\"><strong style=\"box-sizing: border-box;\">Vision</strong></span></h3>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #333333; font-family: \'Times New Roman\'; font-size: 14.6667px;\"><span style=\"font-family: verdana, geneva, sans-serif;\">An internationally accredited university dedicated to innovation and excellence in the service of God and country.</span></p>\n<h3 style=\"box-sizing: border-box; font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: 500; line-height: 1.1; color: #8c0001; margin-top: 20px; margin-bottom: 10px; font-size: 14pt;\"><span style=\"font-family: verdana, geneva, sans-serif;\"><strong style=\"box-sizing: border-box;\">Mission</strong></span></h3>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #333333; font-family: \'Times New Roman\'; font-size: 14.6667px;\"><span style=\"font-family: verdana, geneva, sans-serif;\">The Lyceum of the Philippines University - Cavite, espousing the ideals of Jose P. Laurel, is committed to the following mission:</span></p>\n<ol style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; color: #333333; font-family: \'Times New Roman\'; font-size: 14.6667px;\">\n<li style=\"box-sizing: border-box;\"><span style=\"font-family: verdana, geneva, sans-serif;\">Advance and preserve knowledge by undertaking research and disseminating and utilizing the results. -&nbsp;<strong style=\"box-sizing: border-box;\">RESEARCH</strong></span></li>\n<li style=\"box-sizing: border-box;\"><span style=\"font-family: verdana, geneva, sans-serif;\">Provide equitable access to learning through relevant, innovative, industry-based and environment-conscious programs and services in the context of nationalism and internationalism. -&nbsp;<strong style=\"box-sizing: border-box;\">INSTRUCTION</strong>&nbsp;and&nbsp;<strong style=\"box-sizing: border-box;\">QUALITY SERVICES</strong></span></li>\n<li style=\"box-sizing: border-box;\"><span style=\"font-family: verdana, geneva, sans-serif;\">Provide necessary knowledge and skills to meet entrepreneurial development and the managerial requirements of the industry. -&nbsp;<strong style=\"box-sizing: border-box;\">INSTRUCTION</strong></span></li>\n<li style=\"box-sizing: border-box;\"><span style=\"font-family: verdana, geneva, sans-serif;\">Establish local and international linkages that will be the source of learning and growth of the members of academic community. -&nbsp;<strong style=\"box-sizing: border-box;\">INSTRUCTION</strong>&nbsp;and&nbsp;<strong style=\"box-sizing: border-box;\">INSTITUTIONAL</strong><strong style=\"box-sizing: border-box;\">DEVELOPMENT</strong></span></li>\n<li style=\"box-sizing: border-box;\"><span style=\"font-family: verdana, geneva, sans-serif;\">Support a sustainable community extension program and be a catalyst for social transformation and custodian of Filipino culture and heritage. -&nbsp;<strong style=\"box-sizing: border-box;\">COMMUNITY EXTENSION</strong></span></li>\n<li style=\"box-sizing: border-box;\"><span style=\"font-family: verdana, geneva, sans-serif;\">Build a community of God-centered, nationalistic, environment conscious, and globally competitive professionals with wholesome values and attitudes. -&nbsp;<strong style=\"box-sizing: border-box;\">PROFESSIONALISM</strong>&nbsp;and&nbsp;<strong style=\"box-sizing: border-box;\">VALUES</strong></span></li>\n</ol>','Login'),(3,NULL,'2017-01-26 18:59:15','<div class=\"middle-box text-center animated fadeInDown\">\n<h1 style=\"box-sizing: border-box; margin: 20px 0px 10px; font-size: 170px; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: 100; line-height: 1.1; color: #676a6c; text-align: center; background-color: #f3f3f4;\">401</h1>\n<h3 class=\"font-bold\" style=\"box-sizing: border-box; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 1.1; color: #676a6c; margin-top: 5px; margin-bottom: 10px; font-size: 16px; text-align: center; background-color: #f3f3f4;\">401 - Unauthorized: Access Denied!</h3>\n<div class=\"error-desc\" style=\"box-sizing: border-box; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: normal; text-align: center; background-color: #f3f3f4;\">You do not have permission to view this directory or page!</div>\n</div>','401'),(4,NULL,'2017-01-26 18:36:09','<div class=\"middle-box text-center animated fadeInDown\">\n<h1 style=\"box-sizing: border-box; margin: 20px 0px 10px; font-size: 170px; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: 100; line-height: 1.1; color: #676a6c; text-align: center; background-color: #f3f3f4;\">404</h1>\n<h3 class=\"font-bold\" style=\"box-sizing: border-box; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 1.1; color: #676a6c; margin-top: 5px; margin-bottom: 10px; font-size: 16px; text-align: center; background-color: #f3f3f4;\">Page Not Found</h3>\n<div class=\"error-desc\" style=\"box-sizing: border-box; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: normal; text-align: center; background-color: #f3f3f4;\">Sorry, but the page you are looking for has not been found. Try checking the URL for errors, then hit the refresh button on your browser.</div>\n</div>','404'),(5,NULL,'2017-02-14 23:54:18','<p style=\"padding-left: 30px;\"><span style=\"box-sizing: border-box; font-weight: bold; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\">F-SAO-004 (Copy)&nbsp;</span></p>\n<p style=\"text-align: center;\"><span style=\"box-sizing: border-box; font-weight: bold; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\"><span style=\"box-sizing: border-box; text-align: center;\">LYCEUM OF THE PHILIPPINES UNIVERSITY&nbsp;<br style=\"box-sizing: border-box;\" />Cavite Campus</span><span style=\"font-weight: normal; text-align: center;\">&nbsp;</span><br style=\"box-sizing: border-box; font-weight: normal; text-align: center;\" /><span style=\"font-weight: normal; text-align: center;\">Gen. Trias, Cavite</span></span></p>\n<p style=\"text-align: center;\">&nbsp;</p>\n<h5 style=\"box-sizing: border-box; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 1.1; color: #676a6c; margin-top: 5px; margin-bottom: 10px; font-size: 12px; text-align: center;\">STUDENT AFFAIRS OFFICE</h5>\n<h5 style=\"box-sizing: border-box; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 1.1; color: #676a6c; margin-top: 5px; margin-bottom: 10px; font-size: 12px; text-align: center;\"><u style=\"box-sizing: border-box;\">LOCKER CONTRACT</u></h5>\n<p style=\"text-align: center;\"><label class=\"checkbox-inline\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 0px; position: relative; padding-left: 20px; vertical-align: middle; cursor: pointer; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\"><input style=\"margin: 4px 0px 0px -20px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; font-family: inherit; padding: 0px; position: absolute;\" type=\"checkbox\" value=\"\" />Manila</label><span style=\"color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\">&nbsp;</span><label class=\"checkbox-inline\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 0px; position: relative; padding-left: 20px; vertical-align: middle; cursor: pointer; margin-top: 0px; margin-left: 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\"><input style=\"margin: 4px 0px 0px -20px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; font-family: inherit; padding: 0px; position: absolute;\" type=\"checkbox\" value=\"\" />Makati</label><span style=\"color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\">&nbsp;</span><label class=\"checkbox-inline\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; margin-bottom: 0px; position: relative; padding-left: 20px; vertical-align: middle; cursor: pointer; margin-top: 0px; margin-left: 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px;\"><input style=\"margin: 4px 0px 0px -20px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; font-family: inherit; padding: 0px; position: absolute;\" type=\"checkbox\" value=\"\" />Cavite</label></p>\n<p style=\"text-align: center;\">&nbsp;</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 30px;\">I <label id=\"c_fname\">_______________________________</label>,<label id=\"c_course\">__________________________<label></label> would like to rent one (1) locker unit on a<br style=\"box-sizing: border-box;\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Name of Student) &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (Course &amp; Year)<br style=\"box-sizing: border-box;\" /><input type=\"checkbox\" /> semestral <input type=\"checkbox\" /> yearly basis.<br style=\"box-sizing: border-box;\" /><br style=\"box-sizing: border-box;\" />I hereby agree to the following&nbsp;<em>terms and conditions</em>:</label></p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 30px;\">&nbsp;</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">1. I will pay the locker rental fee of <input type=\"checkbox\" /> two hundred pesos (P200) per semester / <input type=\"checkbox\" /> three hundred and fiftypesos (P350) per school year. In case I discontinue its use, it is understood that the rental fee is non-transferable and non-refundable.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">2. The locker unit assigned to me is in good state. I am therefore responsible for any damage, which may result from my negligence, deliberate destruction, vandalism or acts that I may be found to be at fault. Likewise, I am willing to abide the school\'s regulations against vandalism and destruction of school properties.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">3. I hereby acknowledge that any loss or property inside the rented locker unit is not the responsibility of the school. I shall provide the lock for the unit I am to occupy for its security. However, if an incident of loss occurs, I will inform the Student Affairs Office immediately so that proper investigation may be conducted.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">4. I will maintain the cleanliness and orderliness of my locker.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">5. I am to occupy only the unit designated to me. I will not switch my locker unless authorized by the Student Affairs Office.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">6. I will notify the Student Affairs Office immediately if I decide to discontinue the use of the locker unit assigned to me.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">7. Upon the expiration of this agreement, I agree completely and unconditionally to vacate the aforementioned unit without necessity of demand. Otherwise, my rented locker will be forced open and my personal belongings will be confiscated.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">8. Failure on my part to comply with ant of the&nbsp;<u style=\"box-sizing: border-box;\"><em style=\"box-sizing: border-box;\"><span style=\"box-sizing: border-box; font-weight: bold;\">terms and conditions</span></em></u>&nbsp;stated herein may result in the termination of the contract even before the expiration date.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 60px;\">9. The terms of this agreement will be for the _________________, terminating on___________.</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 360px;\">(Sem. / SY)</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 360px;\">&nbsp;</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 360px;\">Conforme: _________________________</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; text-align: justify; padding-left: 360px;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;(Signature over printed name)</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; padding-left: 30px; text-align: left;\">Home Address________________________ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Locker No._______________________</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; padding-left: 30px; text-align: left;\">____________________________________&nbsp;</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; padding-left: 30px; text-align: left;\">Tel No. _____________________________ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Noted by: _______________________</p>\n<p style=\"box-sizing: border-box; margin: 0px 0px 10px; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; padding-left: 30px; text-align: left;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Dean/Head, Student Affairs Office</p>','Locker Contract');
/*!40000 ALTER TABLE `contents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `no_of_years` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'Bachelor of Science in Medical Technology',4,1),(2,'Bachelor of Science in Pharmacy',4,1),(3,'Bachelor of Science in Radiologic Technology',4,1),(4,'Bachelor of Science in Nutrition and Dietetics',4,1),(5,'Bachelor of Science in Biology',4,1),(6,'Bachelor of Arts in Foreign Service',4,2),(7,'Bachelor of Arts in Communication - with Specialization in Broadcasting',4,2),(8,'Bachelor of Science in Elementary Education - Major in Pre-School Education',4,2),(9,'Bachelor of Science in Secondary Education - Major in English',4,2),(10,'Bachelor of Science in Psychology',4,2),(11,'Bachelor of Arts in Legal Studies',4,2),(12,'Bachelor of Arts in Multimedia Arts',5,2),(13,'Bachelor of Science in Accountancy',5,3),(14,'Bachelor of Science in Business Administration - Major in Human Resource Development Management',4,3),(15,'Bachelor of Science in Business Administration - Major in Management Accounting',4,3),(16,'Bachelor of Science in Business Administration - Major in Marketing Management',4,3),(17,'Bachelor of Science in Business Administration - Major in Operations Management',4,3),(18,'Bacherlor of Science in Customs Administration',4,3),(19,'Bachelor of Science in Real Estate Management',4,3),(20,'Bachelor of Science in Civil Engineering',5,4),(21,'Bachelor of Science in Computer Engineering',5,4),(22,'Bachelor of Science in Electrical Engineering',5,4),(23,'Bachelor of Science in Electronics Engineering',5,4),(24,'Bachelor of Science in Industrial Engineering',5,4),(25,'Bachelor of Science in Mechanical Engineering',5,4),(26,'Bachelor of Science in Information Technology',4,4),(27,'Bachelor of Science in Computer Science',4,4),(28,'Bachelor of Science in Architecture',5,4),(29,'Bachelor of Science in International Travel and Tourism Management',4,5),(30,'Bachelor of Science in International Hospitality Management  - with Specializations in Culinary Arts and Kitchen Operations',4,5),(31,'Bachelor of Science in International Hospitality Management  - with Specializations in Cruise Line Operations in Culinary Arts',4,5),(32,'Bachelor of Science in International Hospitality Management  - with Specializations in Cruise Line Operations in Hotel Services',4,5),(33,'Bachelor of Science in International Hospitality Management  - with Specializations in Hotel and Restaurant Administration',4,5);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `venue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `organization` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `school_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('OnProcess','Reserved','Banned') COLLATE utf8_unicode_ci NOT NULL,
  `start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end` timestamp NULL DEFAULT NULL,
  `remark_status` enum('Approved','Disapproved') COLLATE utf8_unicode_ci NOT NULL,
  `cvf_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'test','Lpu Auditirium','LYCESGO        \r\n           ','2016-2017','OnProcess','2017-03-14 16:00:00','2017-03-14 16:00:00','Approved','17-1');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `exclusions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exclusions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `exclusions` WRITE;
/*!40000 ALTER TABLE `exclusions` DISABLE KEYS */;
/*!40000 ALTER TABLE `exclusions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `itexmo_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itexmo_key` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `api_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `itexmo_key` WRITE;
/*!40000 ALTER TABLE `itexmo_key` DISABLE KEYS */;
INSERT INTO `itexmo_key` VALUES (1,NULL,NULL,'JOHNA237118_FZX48');
/*!40000 ALTER TABLE `itexmo_key` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `locker_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locker_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `building` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `floor` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_added` date NOT NULL,
  `added_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `locker_locations_building_floor_unique` (`building`,`floor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `locker_locations` WRITE;
/*!40000 ALTER TABLE `locker_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `locker_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lockers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lockers` (
  `locker_no` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessee_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lessee_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('Available','Occupied','Damaged','Locked') COLLATE utf8_unicode_ci NOT NULL,
  `start_of_contract` date NOT NULL,
  `end_of_contract` date NOT NULL,
  `location_id` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `added_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`locker_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `lockers` WRITE;
/*!40000 ALTER TABLE `lockers` DISABLE KEYS */;
/*!40000 ALTER TABLE `lockers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lost_and_founds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lost_and_founds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date_reported` date NOT NULL,
  `time_reported` time NOT NULL,
  `school_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `distinctive_marks` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `endorser_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `found_at` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `owner_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `claimer_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_claimed` date NOT NULL,
  `status` enum('Unclaimed','Claimed','Donated') COLLATE utf8_unicode_ci NOT NULL,
  `disposal_date` date NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `claimed_reporter_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `lost_and_founds` WRITE;
/*!40000 ALTER TABLE `lost_and_founds` DISABLE KEYS */;
INSERT INTO `lost_and_founds` VALUES (1,'2017-03-23','01:00:00','2016-2017','Hahaha','Hahah','Hhaha','Hahaha','Hahaha','Hahaha','2017-03-23','Claimed','2017-05-22',1,1),(2,'2017-03-23','01:00:00','2016-2017','Mmm','Mm','Mm','Mm','Mmm','','0000-00-00','Unclaimed','2017-05-22',1,0),(3,'2017-03-23','01:00:00','2016-2017','Wew','Wwe','Wew','Wew','Wew','','0000-00-00','Unclaimed','2017-05-22',1,0);
/*!40000 ALTER TABLE `lost_and_founds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_08_22_134358_create_lost_and_founds_table',1),('2016_08_24_062136_create_roles_table',1),('2016_08_24_062532_create_user_role_table',1),('2016_08_25_063013_create_students_table',1),('2016_08_26_163950_create_violations_table',1),('2016_08_26_182228_create_courses_table',1),('2016_08_26_182256_create_year_levels_table',1),('2016_08_26_182312_create_sanctions_table',1),('2016_08_26_183723_create_violation_reports_table',1),('2016_09_07_090912_create_activities_table',1),('2016_09_15_140523_create_lockers_table',1),('2016_09_19_144327_create_requirements_table',1),('2016_09_21_123522_create_events_table',1),('2016_09_21_184200_create_community_services_table',1),('2016_09_29_023203_create_school_years_table',1),('2016_10_02_232803_create_colleges_table',1),('2016_10_03_005430_create_locker_locations_table',1),('2016_10_04_021701_create_time_logs_table',1),('2016_10_07_025051_create_suspensions_table',1),('2016_10_07_040124_create_exclusions_table',1),('2016_10_17_130857_create_complainants_table',1),('2017_01_26_210314_create_contents_table',1),('2017_02_05_144259_create_text_messages_table',1),('2017_02_06_060453_create_itexmo_key_table',1),('2017_02_13_113636_create_suspension_logs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requirements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `school_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `organization` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deadline` date NOT NULL,
  `requirement1` tinyint(1) NOT NULL,
  `requirement2` tinyint(1) NOT NULL,
  `requirement3` tinyint(1) NOT NULL,
  `requirement4` tinyint(1) NOT NULL,
  `requirement5` tinyint(1) NOT NULL,
  `requirement6` tinyint(1) NOT NULL,
  `requirement7` tinyint(1) NOT NULL,
  `requirement8` tinyint(1) NOT NULL,
  `requirement9` tinyint(1) NOT NULL,
  `requirement10` int(11) NOT NULL,
  `requirement11` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `requirements` WRITE;
/*!40000 ALTER TABLE `requirements` DISABLE KEYS */;
INSERT INTO `requirements` VALUES (1,'2017-03-22 20:47:00','2017-03-22 20:47:00','2016-2017','sample','2017-03-16',0,0,0,0,0,0,0,0,0,0,'haha'),(2,'2017-03-22 20:47:00','2017-03-22 20:47:00','2016-2017','sample','2017-03-16',0,0,0,0,0,0,0,0,0,0,'haha');
/*!40000 ALTER TABLE `requirements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'2017-02-14 17:34:27','2017-02-14 17:34:27','Admin','SAO Administrator'),(2,'2017-02-14 17:34:27','2017-02-14 17:34:27','Secretary','SAO Secretary');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sanctions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sanctions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `offense_no` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sanctions` WRITE;
/*!40000 ALTER TABLE `sanctions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sanctions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `school_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_years` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `term_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `end` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `school_years` WRITE;
/*!40000 ALTER TABLE `school_years` DISABLE KEYS */;
INSERT INTO `school_years` VALUES (1,'2015-2016','First Semester','2015-06-01','2015-10-31'),(2,'2015-2016','Second Semester','2015-11-01','2016-03-31'),(3,'2015-2016','Summer','2016-04-01','2016-05-31'),(4,'2015-2016','School Year','2015-06-01','2016-05-31'),(5,'2016-2017','First Semester','2016-06-01','2016-10-31'),(6,'2016-2017','Second Semester','2016-11-01','2017-03-31'),(7,'2016-2017','Summer','2017-04-01','2017-05-31'),(8,'2016-2017','School Year','2016-06-01','2017-05-31');
/*!40000 ALTER TABLE `school_years` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `student_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `course` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year_level` enum('1st','2nd','3rd','4th','5th') COLLATE utf8_unicode_ci NOT NULL,
  `student_contact_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_status` enum('Active','Excluded') COLLATE utf8_unicode_ci NOT NULL,
  `guardian_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `guardian_contact_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`student_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('2014-03088','Elmar','Anchuelo','Bachelor of Science in Nutrition and Dietetics','4th','+639230938388','Active','Mama Anchuelo','','2017-03-23'),('2014-03093','Craven John','Delos Santos','Bachelor of Science in Information Technology','4th','+639367936905','Active','','','2017-02-15');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suspension_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suspension_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `suspension_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suspension_logs` WRITE;
/*!40000 ALTER TABLE `suspension_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `suspension_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suspensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suspensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `violation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `suspension_days` int(11) NOT NULL,
  `status` enum('On going','Completed') COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suspensions` WRITE;
/*!40000 ALTER TABLE `suspensions` DISABLE KEYS */;
INSERT INTO `suspensions` VALUES (4,'SAO-1',10,'On going','2014-03093');
/*!40000 ALTER TABLE `suspensions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `text_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `text_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `recipient` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('Manual','Violation Notification','Community Service Notification','Suspension Notification') COLLATE utf8_unicode_ci NOT NULL,
  `sent` tinyint(1) NOT NULL,
  `date_sent` date NOT NULL,
  `time_sent` time NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `text_messages` WRITE;
/*!40000 ALTER TABLE `text_messages` DISABLE KEYS */;
INSERT INTO `text_messages` VALUES (1,'2017-03-01 21:09:34','2017-03-01 21:09:34','09367936905','hahaha','Manual',1,'2017-03-02','05:09:00'),(2,'2017-03-01 21:10:08','2017-03-01 21:10:08','09367936905','ewe','Manual',1,'2017-03-02','05:10:00'),(3,'2017-03-01 21:11:26','2017-03-01 21:11:26','09367936905','ewew','Manual',1,'2017-03-02','05:11:00'),(4,'2017-03-01 21:53:26','2017-03-01 21:53:26','09367936905','hahahaasd','Manual',1,'2017-03-02','05:53:00'),(5,'2017-03-01 21:55:08','2017-03-01 21:55:08','09367936905','great!','Manual',1,'2017-03-02','05:55:00');
/*!40000 ALTER TABLE `text_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `time_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cs_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `time_logs` WRITE;
/*!40000 ALTER TABLE `time_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,NULL,NULL,1,1),(2,NULL,NULL,2,1),(3,NULL,NULL,3,2);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'my_avatar.jpg',
  `contact_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_contact_no_unique` (`contact_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Craven','Delos Santos','delossantoscraven@gmail.com','$2y$10$yX1buUPzhnkMYWg1t1Y4We4.AukTQVFBn4FWtL4Eu95SA7btryC86','1489897850.jpg','+639367936905','388 3rd St., Salinas, Bacoor, Cavite','1996-11-17','lB4D6i9nH1ISzCnTTAp1DG8rfO02SaB4vnFge5e9b8fpHaM3jWLDVX4imj8q','2017-02-14 17:34:27','2017-03-22 23:51:58'),(2,'Elmar','Anchuelo','ejanchuelo@gmail.com','$2y$10$vA0Cfgy8ji7L.O7IwzOVseU8EOn4RsJ8PLdwbB/91zBE8S8LRevc2','my_avatar.jpg','+63921345678','Tierra Nevada, General Trias, Cavite','1990-11-01','aTn3jwqxJFShaD2rrra2GgJVIOSjaDnE13RPXdN7MWhYeFOYmTOqKj9zVdqf','2017-02-14 17:34:27','2017-02-16 06:57:51'),(3,'Kim','Comission','kim@gmail.com','$2y$10$sP.SNWC9Hx9pPgdTyhZXVeBWRnUCahcbc4mHo2gtkoootuKarElVS','my_avatar.jpg','+639873627444','Manggahan, General Trias, Cavite','1994-01-01','unFf86NQZIB4x2GT8cBgTwPoRyMeK2VeUdVGeSVyW41L1XaPTmtkxzaPe3tz','2017-02-14 17:34:27','2017-02-16 17:07:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `violation_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `violation_reports` (
  `rv_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `student_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `violation_id` int(11) NOT NULL,
  `offense_no` int(11) NOT NULL,
  `sanction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `offense_level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `complainant_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Pending','On Going','Completed') COLLATE utf8_unicode_ci NOT NULL,
  `date_reported` date NOT NULL,
  `time_reported` time NOT NULL,
  `school_year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `validity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reporter_id` int(11) NOT NULL,
  PRIMARY KEY (`rv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `violation_reports` WRITE;
/*!40000 ALTER TABLE `violation_reports` DISABLE KEYS */;
INSERT INTO `violation_reports` VALUES ('SAO_VR-12','2014-03093',41,2,'if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given','Very Serious','2014-0001f','Pending','2017-03-23','14:00:00','2016-2017','',1),('SAO-1','2014-03093',35,1,'10-day suspension to and replacement/restoration of damaged items','Very Serious','2014-0002f','On Going','2017-02-15','02:00:00','2016-2017','',1),('SAO-10','2014-03093',41,1,'Range: 10-day suspension to exclusion','Very Serious','2014-0001f','Pending','2017-03-23','03:00:00','2016-2017','',1),('SAO-11','2014-03093',26,1,'Five-Day university/Community Work','Serious','2014-0001f','Pending','2017-03-23','11:00:00','2016-2017','',1),('SAO-2','2014-03093',32,1,'Range: 10-day suspension to exclusion','Very Serious','2014-0001f','Pending','2017-03-02','01:04:00','2016-2017','',1),('SAO-3','2014-03093',20,1,'Five-Day university/Community Work','Serious','2014-0001f','Pending','2017-03-02','01:00:00','2016-2017','',1),('SAO-4','2014-03093',1,1,'Written warning','Less Serious','2014-0001f','Pending','2017-03-02','01:06:00','2016-2017','',1),('SAO-5','2014-03093',1,2,'One-day university / community work','Less Serious','2014-0001f','Pending','2017-03-02','01:05:00','2016-2017','',1),('SAO-6','2014-03093',42,1,'Range: 10-day suspension to exclusion','Very Serious','2014-0001f','Pending','2017-03-23','03:00:00','2016-2017','',1),('SAO-7','2014-03088',49,1,'Range: 10-day suspension to exclusion','Very Serious','2014-0001f','Pending','2017-03-23','02:00:00','2016-2017','',1),('SAO-8','2014-03088',51,1,'Non-readmission/exclusion','Very Serious','2014-0001f','Pending','2017-03-23','03:00:00','2016-2017','',1),('SAO-9','2014-03093',11,1,'Written warning','Less Serious','2014-0001f','Pending','2017-03-23','03:00:00','2016-2017','',1);
/*!40000 ALTER TABLE `violation_reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `violations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `violations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `offense_level` enum('Less Serious','Serious','Very Serious') COLLATE utf8_unicode_ci NOT NULL,
  `first_offense_sanction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `second_offense_sanction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `third_offense_sanction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `violations` WRITE;
/*!40000 ALTER TABLE `violations` DISABLE KEYS */;
INSERT INTO `violations` VALUES (1,NULL,NULL,'Disruptive Students Behavior','Shouting, Conducting, Boisterous Conversation, and creating disruptive noise that may disturb on going classes','Less Serious','Written warning','One-day university / community work','Three-day university/community work'),(2,NULL,NULL,'Unauthorized use of cellphones and similar gadjets during classes or lectures','  Unauthorized use of cellphones and similar gadjets during classes or lectures','Less Serious','Written warning','One-day university / community work','Three-day university/community work '),(3,NULL,NULL,'Unauthorized use of electric outlets of the university','','Less Serious','Oral warning','One-day university / community work','Three-day university/community work '),(4,NULL,NULL,'Library Violations','violation of library rules and regulations.','Less Serious','Written warning','One-day university / community work','Three-day university/community work '),(5,NULL,NULL,'Littering','Littering','Less Serious','Written warning','One-day university / community work','Three-day university/community work '),(6,NULL,NULL,'Student Officers','Failure of student government or student organization officers to fulfill their respective functions in accordance with the student government\'s or constitution and by-laws','Less Serious','Written warning','One-day university / community work','Three-day university/community work + recommendation for impeachment'),(7,NULL,NULL,'Violation of ID guidelines','failure to wear the ID within university premises','Less Serious','Written warning','One-day university / community work','Three-day university/community work'),(8,NULL,NULL,'Violation of uniform and grooming guidelines','improper/ unauthorized uniform, not wearing prescribed uniform, innappropriate attire','Less Serious','Oral warning','Written warning','Two-day university/community work '),(9,NULL,NULL,'Overt behavior a typical of one\'s Sex','Cross-Dressing,Wearing excessive make-up','Less Serious','Oral warning','Written warning','Two-day university/community work '),(10,NULL,NULL,'Unauthorized announcements, Print-outs and campaigns','unauthorized distribution or posting withinn university premises of leaflets, handbills, or other printed materials.','Less Serious','Written warning','Two-day university/community work ','Three-day university/community work '),(11,NULL,NULL,'Foul Language','using foul or vulgar language','Less Serious','Written warning','Two-day university/community work ','Three-day university/community work '),(12,NULL,NULL,'Wearing Inappropriate attire in playing areas','wearing leather shoes and/or other inappropriate attire in the playing area (roof deck)','Less Serious','Written warning','Two-day university/community work ','Three-day university/community work '),(13,NULL,NULL,'Other offenses deemed less-serious by SAO','Other offenses deemed less-serious by SAO','Less Serious','Oral warning','Written warning','Two-day university/community work '),(14,NULL,NULL,'Plagiarism','Act of plagiarism publised or unpublished in official publication','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(15,NULL,NULL,'Offense against LPU\'s name/ reputation ( with lesser penalties)','offenses incurred while wearing any of the LPU uniforms or LPU ID outside the university premises (smoking,drinking,gambling)','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(16,NULL,NULL,'Offenses Concerning LPU\'s premises and facilities','use of university premises and/or facilies without permit,locker violations','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(17,NULL,NULL,'Unsanitary practices','spitting in public areas, improper disposal of waste materials','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(18,NULL,NULL,'Acts of disrespect','Acts of disrespect in word or in deed directed at any member of the academic community','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(19,NULL,NULL,'Misrepresentation','Lending or borrowing of IDs, EAF and/or officials documents','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(20,NULL,NULL,'Gambling','maintaing or participating in any game of chance and other similar activities within the university premises','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(21,NULL,NULL,'Refusal to cooperate with persons in authority','running awa from a person in authority to avoid apprehension','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(22,NULL,NULL,'Computer Offenses','Playing Computer Games, Watching movie,video clips and similarly irrelevant to school','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(23,NULL,NULL,'Indecent display of affection','indecent display of affection within the university premises such as kissing, necking, petting, and the like which scandalize the academic community','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(24,NULL,NULL,'Entering campus while under the influence of liquor','Entering campus while under the influence of liquor','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(25,NULL,NULL,'Entering and using the restroom of the opposite sex','Entering and using the restroom of the opposite sex','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(26,NULL,NULL,'Exiting through the windows and/or walking along the window canopy','Exiting through the windows and/or walking along the window canopy','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(27,NULL,NULL,'Commission of three less serious offenses(of different types)','Commission of three less serious offenses within the semester ( if the offenses are different types)','Serious','Five-Day university/Community Work','Ten-day suspension',''),(28,NULL,NULL,'Repeated commision of less serious offenses of the same type elevated to serious offense status','Repeated commision of less serious offenses of the same type elevated to serious offense status','Serious','Five-Day university/Community Work','Ten-day suspension','Sixth commision of less-serious offense is equivalent to Non-readmission'),(29,NULL,NULL,'Attending classes without LPU approval','attending classes without having duty enrolled therein or not completing registration, attending different class without  approved transfer form','Serious','Ten-Day university/Community Work','Non-readmission',''),(30,NULL,NULL,'Unintentional damage to university property','Unintentional damage to university property','Serious','Three-Day university/Community Work and replacement/restoration of damaged items','Five-Day university/Community Work and replacement/restoration of damaged items',''),(31,NULL,NULL,'Other offenses deemed serious by SAO','Other offenses deemed serious by SAO','Serious','Five-Day university/Community Work','Ten-day suspension','Non-readmission'),(32,NULL,NULL,'Cheating','cheating in any form in relation to an examination, test or written report.','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(33,NULL,NULL,'Offense against LPU\'s name/ reputation ( with stiffer penalties)','use of the name of LPU in, but not limited to, soliciting funs for private purposes, and similar acts','Very Serious','Range: 15-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(34,NULL,NULL,'Unauthorized solicitaion/misuse of funds','solicitation of money, donations, contribution in cash without the prior approval of the proper authority','Very Serious','15-day suspension to exclusion','Exclusion',''),(35,NULL,NULL,'Intentional damage to university property','Intentional destruction of university property.','Very Serious','10-day suspension to and replacement/restoration of damaged items','Non-readmission and replacement/restoration of damaged items',''),(36,NULL,NULL,'Refusal to replace/restore damaged items','Resusal to replace/restore damaged items','Very Serious','10-day suspension to and replacement/restoration of damaged items','Non-readmission and replacement/restoration of damaged items',''),(37,NULL,NULL,'Intentional Disruption of university functions','leading or otherwise taking part in any concerted activity which disrupts university functions','Very Serious','10-day suspension to and replacement/restoration of damaged items, if any','Non-readmission',''),(38,NULL,NULL,'Taking examinations without the official permit and/or using another students permit','Taking examinations without the official permit and/or using another students permit','Very Serious','10-day suspension','Non-readmission',''),(39,NULL,NULL,'Intoxication','entering the university premises while intoxicated, ','Very Serious','15 or 10-day suspension to exclusion','Non-readmission',''),(40,NULL,NULL,'Smoking within the university premises','smoking and use of similar gadgets and substanses within the university premises','Very Serious','10-day suspension','Non-readmission',''),(41,NULL,NULL,'Fist Fighting','involvement in fist fights and similar actions inside and outside campus that affect the name of LPU','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(42,NULL,NULL,'Brawling','involvement in bawls and similar actions inside and outside campus that affect the name of LPU','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(43,NULL,NULL,'Scandalous acts in the internet','committing any scandalous act in the websitel posting scandalous pictures or video on the website','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(44,NULL,NULL,'Immoral sexual acts','perverted behaviors','Very Serious','10-day to 20-day suspension','Non-readmission',''),(45,NULL,NULL,'Very serious computer offenses','unauthorized use of LPU\'s computer and peripheral systems and networks, posting defamatory comments','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(46,NULL,NULL,'Extortion or Blackmail','Extortion or Blackmail, whether the purpose or objective is accomplished or not','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(47,NULL,NULL,'Tampering of university records','Tampering of university records','Very Serious','Non-readmission/exclusion','',''),(48,NULL,NULL,'Threat againts member of the academic community','Threatening University officials, faculty members, personnel and/or fellow students in any manner','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(49,NULL,NULL,'Harrasment or physical abuse','Assaulting, challenging, or committing physical abuse, harrasment, or similar acts against persons in authority, faculty members, personnel, and fellow students','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(50,NULL,NULL,'Illegal and/or violent activities','Instigating, inciting, provoking, leading, or taking part (active or passively) in illega and/or violent demonstrations or activities','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(51,NULL,NULL,'Fraternities, sororities and non-accredited organizations','Recruitment/membership in  fraternity/sorority or any student organization not accredited by the Lyceum of the Philippines University - Cavite Campus','Very Serious','Non-readmission/exclusion','',''),(52,NULL,NULL,'Hazing','Hazing or subjecting a person to physical or mental injury for the purpose of admission and/or maintenance of membership in any organization, whether recognized or unrecognized','Very Serious','Exclusion','',''),(53,NULL,NULL,'Arson','Arson','Very Serious','Exclusion','',''),(54,NULL,NULL,'Use and/or possesion of deadly weapons and explosives','Possession of explosives, firearms, knives, or any deadly weapons within the University premises','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(55,NULL,NULL,'Robbery,theft, and other similar offenses','Robbery, thievery, and acts of malicious mischief involving University property or that of the members of the academic community, including visitors','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(56,NULL,NULL,'Possession and/or trafficking of probihited drugs','Possession and/or trafficking of probihited drugs','Very Serious','Exclusion','',''),(57,NULL,NULL,'Court Conviction','Conviction by a court of law of a crime involving moral turpitude','Very Serious','Non-readmission/exclusion','',''),(58,NULL,NULL,'Treacherous acts/sabotage',' Acts of threachery and sabotage including arson, tampering with electronic connections, switches, generators, elevators, motors, air conditioners, and fire-alarm systems','','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(59,NULL,NULL,'Commission of three (3) serious offenses within a semester','nto yet available','Very Serious','Range: 10-day suspension to exclusion','if suspension was imposed as sanction for the first offense the sanction of non-eadmission or exclusion shall be given',''),(60,NULL,NULL,'Other offenses deemed very-serious by SAO','not yet available','Very Serious','10-day suspension','Non-readmission/exclusion','');
/*!40000 ALTER TABLE `violations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `year_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `year_levels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `year_levels` WRITE;
/*!40000 ALTER TABLE `year_levels` DISABLE KEYS */;
/*!40000 ALTER TABLE `year_levels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

